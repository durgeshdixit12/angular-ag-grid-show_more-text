import { Component } from '@angular/core';
import TextCellRenerer from './text-cell-renderer';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ag-grid';
  public expandedRowId: Number;

  public gridOptions = {
    columnDefs: [
      {headerName: 'Make',        field: 'make',        sortable:     true        },
      {headerName: 'Model',       field: 'model',       sortable:     true        },
      {headerName: 'Price',       field: 'price',       filter:       true        },
      {headerName: 'Description', field: 'description', cellRenderer: 'textCells' },
      {headerName: 'Details',     field: 'details',     cellRenderer: 'textCells' },
      {headerName: 'Year',        field: 'year'                                   }
    ],
    components: {
      textCells: TextCellRenerer,
    },
    defaultColDef: {
      width: 170,
      sortable: true,
      editable: true,
      resizable: true,
      autoHeight: true,
      filter: true,  
    },
    // onColumnResized: this.onColumnResized,
    rowData: [
      { 
        id: 2,
        make: 'Toyota',
        model: 'Celica',
        price: 35000,
        description: 'Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. ',
        details: 'Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. ',
        year: 2020
      },
      {
        id: 3,
        make: 'Ford',
        model: 'Mondeo',
        price: 32000,
        description: 'Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. ',
        details: 'Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. ',
        year: 2020
      },
      {
        id: 4,
        make: 'Porsche',
        model: 'Boxter',
        price: 72000,
        description: 'Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. Some extra long text. ',
        details: 'Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. Some medium scale long text. ',
        year: 2020
      }
    ],
    scope: this,
    rowHeight: 35,
  };

  onColumnResized(params) {
    params.api.resetRowHeights();
  }
}
