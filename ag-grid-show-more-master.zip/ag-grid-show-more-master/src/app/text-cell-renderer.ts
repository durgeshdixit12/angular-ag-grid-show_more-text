function TextCellRenerer () {}

function isOverflown (el) {
  return (el.offsetWidth < el.scrollWidth || el.offsetHeight < el.scrollHeight);
}

TextCellRenerer.prototype.init = function (params) {
  const p = document.createElement('span');
  p.innerText = params.value;

  p.classList.add('custom-ag-cell');
  p.classList.add('default-width');
  document.body.appendChild(p);
  const overFlown = isOverflown(p);
  p.classList.remove('default-width');

  if (overFlown) {
    document.body.removeChild(p);
    const span = document.createElement('span');
    span.classList.add('show-more');
    span.innerText = 'Show More';
    span.onclick = function (e) {

        const target = e.target as HTMLSpanElement;

        target.attributes['']

        if (target.classList.contains('is-expanded')) {
            const row = params.eGridCell.closest('.ag-row');
            row.classList.remove('expanded');
            const cells = document.querySelectorAll('.ag-row[row-index="' + params.rowIndex + '"] .custom-ag-cell');
            const showMoreButtons = document.querySelectorAll('.ag-row[row-index="' + params.rowIndex + '"] .show-more');
    
            for (let idx = 0; idx < showMoreButtons.length; idx++) {
                let span = showMoreButtons[idx] as HTMLSpanElement;
                span.classList.remove('is-expanded');
                span.innerText = 'Show More';
            }

            setTimeout(() => params.node.setRowHeight(40));
            setTimeout(() => params.api.onRowHeightChanged());
        } else {
            const previouslyExpandedRow = document.querySelectorAll('.ag-row.expanded')[0];
            if (previouslyExpandedRow) {
                const previousRowId = previouslyExpandedRow.getAttribute('row-index');
                const showMoreButton: HTMLSpanElement = document.querySelector('.ag-row[row-index="' + previousRowId + '"] .show-more');
                console.log(showMoreButton);
                showMoreButton.click();
            }

            const row = params.eGridCell.closest('.ag-row').classList.add('expanded');
    
            const cells = document.querySelectorAll('.ag-row[row-index="' + params.rowIndex + '"] .custom-ag-cell');
            const showMoreButtons = document.querySelectorAll('.ag-row[row-index="' + params.rowIndex + '"] .show-more');
    
            let maxHeight = 0;
    
            for (let idx = 0; idx < showMoreButtons.length; idx++) {
                let span = showMoreButtons[idx] as HTMLSpanElement;
                span.classList.add('is-expanded');
                span.innerText = 'Show Less';
            }
            for (let idx = 0; idx < cells.length; idx++) {
                let span = cells[idx] as HTMLSpanElement;
                maxHeight = Math.max(maxHeight, span.scrollHeight);
            }
            setTimeout(() => params.node.setRowHeight(maxHeight + 25));
            setTimeout(() => params.api.onRowHeightChanged());
            // console.log(params, row);
        }
    }

    const container = document.createElement('div');
    container.classList.add('cell-container');
    container.append(p);
    container.appendChild(span);

    this.eGui = container;
  } else {
    this.eGui = p;
    document.body.removeChild(p);
  }

}

TextCellRenerer.prototype.getGui = function () {
  return this.eGui;
}

export default TextCellRenerer;
